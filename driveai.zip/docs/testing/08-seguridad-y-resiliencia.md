# 08 · Seguridad, resiliencia y análisis estático (eje E)

## 1. Modelo de amenazas (resumen)

| Amenaza | Vector | Control implementado | Verificación |
| --- | --- | --- | --- |
| Robo de sesión | JWT manipulable | Firma HMAC, issuer, expiración, rechazo de `alg=none` | `JwtServiceTest` (7) |
| BOLA / IDOR | `userId`/`sessionId` del cliente | Propiedad derivada del JWT; 404 en recursos ajenos | `CartServiceTest`, `OrderServiceTest`, `ApiContractIT`, E2E |
| BFLA | CUSTOMER llamando endpoints admin | `@PreAuthorize` + reglas de `SecurityConfig` | `ApiSecurityTest`, `ApiContractIT`, E2E |
| Mass assignment | `role`, `id`, `version` en el body | DTOs de escritura sin campos sensibles | `ApiContractIT`, `CarServiceTest` |
| Fuerza bruta | Login ilimitado | Rate limit 5/min por IP → 429 + `Retry-After` | `LoginRateLimitServiceTest` |
| Inyección SQL | Parámetros de filtros | JPA/Criteria parametrizado | `CarSpecificationTest` |
| XSS | Datos del LLM / catálogo | React escapa por defecto; sin `dangerouslySetInnerHTML` | E2E IA |
| XXE | XML SOAP malicioso | DTD y entidades externas deshabilitadas | `SoapVehicleClientTest` |
| Fuga de información | Stack traces / errores internos | Problem Details sin stack trace | `ApiSecurityTest`, `ApiContractIT` |
| CORS abierto | Origen arbitrario | Allowlist explícita, sin comodín con credenciales | `SecurityConfig` |
| Clickjacking / sniffing | iframes, MIME | `frame-ancestors 'none'`, `X-Content-Type-Options` | `ApiSecurityTest` |
| Secretos en repo | `.env`, historial | `.env` ignorado, `.env.example` sin secretos | Gitleaks / revisión manual |

## 2. Autenticación y autorización

- Contraseñas con **BCrypt**.
- JWT firmado; el filtro construye un `UserPrincipal` desde `uid`/`role` y rechaza roles
  desconocidos.
- Validaciones cubiertas por tests: firma alterada, token expirado, issuer incorrecto,
  `alg=none`, secreto corto y rol inválido.
- Endpoints de administración protegidos en el backend, no solo ocultos en la UI.
- El frontend muestra "Acceso restringido" a un CUSTOMER en `#/admin`, pero la
  autorización real la aplica el backend (403).

## 3. BOLA / IDOR

Antes del refactor, el carrito y las órdenes aceptaban `sessionId`/`userId` del cliente.
Ahora:

- `CartController` y `OrderController` obtienen el usuario de `@AuthenticationPrincipal`.
- Los DTOs ya no aceptan `sessionId`.
- Un usuario B que intenta leer o modificar un recurso de A recibe **404** (no se filtra
  la existencia del recurso).

Verificado en `CartServiceTest`, `OrderServiceTest`, `ApiContractIT` y E2E.

## 4. Mass assignment

`CarWriteRequest`, `RegisterRequest`, `CheckoutRequest` y `CartAddRequest` solo exponen
los campos permitidos. Un body con `id`, `version` o `role` no modifica esos valores;
`ApiContractIT` lo comprueba creando un auto con `role: ADMIN` e `id` arbitrario.

## 5. Cabeceras y CORS

`SecurityConfig` agrega:

- `Content-Security-Policy`
- `Strict-Transport-Security`
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY` / `frame-ancestors 'none'`
- `Referrer-Policy`
- CORS con `CORS_ALLOWED_ORIGINS` (default `http://localhost:5173,http://localhost:4173`),
  sin `*` cuando hay credenciales.

Actuator expone solo `health` e `info`.

## 6. Escaneo de secretos (Gitleaks)

- `.env` y `.tools/` están en `.gitignore`; solo se versiona `.env.example` con valores
  vacíos/placeholder.
- Se hizo una búsqueda manual de los secretos reales (JWT y `GROQ_API_KEY`) en todo el
  historial: **0 coincidencias**.
- **Hallazgo D-01 (cerrado el 10/11/2026):** la contraseña de demo aparecía en el README
  de 3 commits (`3f19436`, `4d0e6d7`, `43903d0`) y una clave JWT de prueba de alta
  entropía en `ApiContractIT.java`. Con autorización del equipo se reescribió el
  historial (`15-saneamiento-historial-D01.md`), se rotó `ADMIN_PASSWORD` y se verificó
  con Gitleaks 8.30.1 sobre todo el historial: **`no leaks found`**.
- En CI Gitleaks ahora es **bloqueante** y corre dos veces en `security-scan`: la action
  sobre los commits del push y `gitleaks git --log-opts="--all" --exit-code 1` sobre el
  historial completo.

## 7. Dependencias y DAST

| Herramienta | Estado | Observación |
| --- | --- | --- |
| **SpotBugs 4.8.6.6** | ✅ 0 hallazgos | `mvn -B spotbugs:check` con `failOnError=true`; ver §8 |
| **Trivy** (dependencias) | CI run #5 (10/11): 7 HIGH → corregidas 6, mitigada 1 (DEF-14). **Run de `main` (42867141379): 0 hallazgos** | `severity CRITICAL,HIGH`, bloqueante. Excepción documentada: CVE-2026-22733 en `.trivyignore` (Cloud Foundry no usado y deshabilitado) |
| **OWASP ZAP API scan** (pasivo + activo, autenticado) | ✅ CI, job `dast-zap`, run de `main`: **0 High · 0 Medium · 3 Low · 3 Informational**, 118 reglas PASS | Falla con alertas High (`ci/check-zap.py`); no hubo Medium que justificar; las Low se comentan en §11 |
| **Gitleaks 8.30.1** | ✅ `no leaks found` sobre el historial completo (10/11, tras sanear D-01) | Bloqueante en CI sobre los commits del push (action) y sobre todo el historial (`docker run … gitleaks git --log-opts="--all" --exit-code 1`) |

### Checklist ZAP manual (para ejecutar con el stack arriba)

```bash
# Baseline pasivo
docker run --rm -t -v "$(pwd)/zap:/zap/wrk" \
  ghcr.io/zaproxy/zap-stable zap-baseline.py \
  -t http://host.docker.internal:8080 -r zap-baseline.html

# Active scan autenticado (requiere token de un usuario de prueba)
docker run --rm -t -v "$(pwd)/zap:/zap/wrk" \
  ghcr.io/zaproxy/zap-stable zap-full-scan.py \
  -t http://host.docker.internal:8080 -r zap-full.html
```

Puntos a revisar en el reporte:

- Ausencia de `Content-Security-Policy` / `HSTS` (ya configurados).
- CORS permisivo (allowlist).
- Cookies sin `HttpOnly`/`Secure` (no se usan cookies: JWT en `Authorization`).
- Divulgación de versiones en cabeceras.
- Formularios sin anti-CSRF (API stateless con Bearer; no aplica).
- XSS reflejado en parámetros de búsqueda.

## 8. Análisis estático (SpotBugs)

```bash
cd backend
mvn -B spotbugs:check
```

Resultado real:

```
BugInstance size is 0
Error size is 0
No errors/warnings found
BUILD SUCCESS
```

Se configuró `backend/config/spotbugs-exclude.xml` para falsos positivos justificados
(inyección de dependencias de Spring, records DTO, constructor fail-fast de `JwtService`,
saltos de línea en text blocks de XML/SOAP). El filtro está versionado y es auditable.

## 9. Resiliencia

### 9.1 Integración SOAP

| Requisito | Implementación | Evidencia |
| --- | --- | --- |
| Timeout 5 s | `JdkClientHttpRequestFactory` + `HttpClient` HTTP/1.1 | `SoapVehicleClientTest` |
| Reintento acotado | Resilience4j `retry` (2 intentos, 300 ms) solo para fallos técnicos | `SoapVehicleClientTest` |
| Circuit breaker | Resilience4j `circuitbreaker` con exclusión de faults de negocio | configuración + tests |
| Fallback | Respuesta controlada si el proveedor no responde | `SoapVehicleClientTest` |
| Fault de negocio | Se mapea a 409 y **no** se reintenta ni se oculta | `SoapVehicleClientTest` |
| XXE | Parser con DTD/entidades externas deshabilitadas | `SoapVehicleClientTest` |

### 9.2 Mensajería

| Requisito | Implementación | Evidencia |
| --- | --- | --- |
| Outbox transaccional | `outbox_events` en la misma transacción de la orden | `OutboxServiceTest` |
| Publicación confiable | `OutboxPublisher` reintenta y marca `SENT` | `OutboxPublisherTest` |
| Broker caído | El evento queda `PENDING` y se reintenta; se recupera solo al volver (los fallos técnicos no lo descartan) | `OutboxPublisherTest`, `MessagingIT` |
| Consumidor idempotente | `processed_messages` deduplica por `message_id` | `OrderEventsListenerTest`, `MessagingIT` |
| DLQ | Exchange/queue con dead-letter exchange | `MessagingConfigTest`, `MessagingIT` |
| Mensaje inválido | Se rechaza y va a la DLQ | `MessagingIT` |

### 9.3 Transacciones e idempotencia

- Checkout transaccional con bloqueo pesimista y descuento de stock.
- Si falla, **rollback**: no queda orden ni stock descontado.
- `Idempotency-Key` respaldada por base (`idempotency_keys`):
  - replay devuelve la misma orden,
  - concurrencia resuelve con `INSERT … ON CONFLICT`,
  - mismo key con payload distinto → 409,
  - si la operación falla, la clave se libera.
- ETag/`If-Match` para concurrencia optimista en autos → 412.
- Máquina de estados de órdenes → 409 ante transiciones inválidas.

### 9.4 Errores uniformes

Todos los errores usan **RFC 9457 / RFC 7807** (`application/problem+json`) con
`type`, `title`, `status`, `detail` e `instance`, sin stack traces ni datos internos.
Códigos cubiertos: 400, 401, 403, 404, 409, 412, 422, 429, 500, 503.

## 10. Resultado consolidado

| Control | Estado |
| --- | --- |
| JWT (firma, expiración, issuer, `alg=none`) | ✅ |
| BOLA/IDOR carrito y órdenes | ✅ |
| BFLA admin | ✅ |
| Mass assignment | ✅ |
| Rate limit login / IA | ✅ |
| Cabeceras de seguridad y CORS | ✅ |
| XXE | ✅ |
| SpotBugs | ✅ 0 hallazgos |
| Gitleaks | ✅ historial saneado (D-01 cerrado 10/11), 0 hallazgos |
| Trivy | ✅ CI (run de `main`): 0 hallazgos CRITICAL/HIGH |
| ZAP | ✅ CI (run de `main`): 0 High / 0 Medium |
| Resiliencia SOAP / broker / outbox | ✅ unitarias · ✅ IT 18/18 (local 10/11 y CI) |

## 11. Revisión del 10/11/2026 (criterios Clase 15)

| Hallazgo | Severidad | Estado |
| --- | --- | --- |
| DEF-07: rate limit de login evadible rotando IP / `X-Forwarded-For` | Crítica | Cerrado: verificado en CI sobre `main` (G7-12) |
| DEF-08: rate limit de IA evadible cambiando `sessionId` | Crítica | Cerrado: verificado en CI sobre `main` (G7-13) |
| DEF-11: la SPA (nginx) no enviaba CSP/HSTS/`X-Content-Type-Options` | Mayor | Corregido: cabeceras con `curl` y navegación sin violaciones de CSP (10/11); falta la pasada con `docker compose up` (G7-16) |

Detalle en `10-registro-defectos.md`.

### Alertas de ZAP (run de `main` 42867141379, `zap-report/zap-api.json`)

No hubo alertas **High** ni **Medium**, así que no hay justificaciones pendientes para
el criterio del Eje D. Se documentan igual las Low, por transparencia:

| Alerta (pluginId) | Riesgo | Endpoint | Justificación |
| --- | --- | --- | --- |
| A Server Error response code was returned by the server (100000) | Low | `POST /api/ai/recommend` | El 503 es el fallback controlado del asesor sin `GROQ_API_KEY` en CI (D-02, aceptado por diseño); Problem Details sin stack trace |
| Cross-Origin-Resource-Policy Header Missing or Invalid (90004) | Low | `GET /api/cars`, `GET /api/cars/{id}`, `GET /api/cart`, `GET /v3/api-docs`, `POST /api/orders/checkout` | API JSON consumida solo por la SPA del mismo origen vía nginx; `CORS` con allowlist y `Cross-Origin-Opener-Policy` en la SPA. Agregar `Cross-Origin-Resource-Policy: same-origin` en `SecurityConfig` queda como mejora para la 4.ª entrega |
| Timestamp Disclosure - Unix (10096) | Low | `GET /api/cars/{id}`, `GET /api/orders`, `POST /api/orders/checkout` | Falso positivo: la "evidencia" `1560958089` es el id de la foto de Unsplash en `imageUrl` (`photo-1560958089-…`, `V2__seed_cars.sql`), no un timestamp del servidor |

_Al crear el tag, volver a bajar `zap-report` del run del tag y confirmar que la tabla
no cambia._

